export default {
  "bootstrapScriptContent": "import(\"/_next/static/chunks/index-CTjh5y2D.js\")",
  "clientReferenceDeps": {
    "6674cdf89eee": {
      "js": [
        "/_next/static/chunks/admin-client-BFYvHcrB.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/site-footer-D9UXbJb6.js",
        "/_next/static/chunks/site-header-NG0pkwPJ.js",
        "/_next/static/chunks/Icon-nzziIqKm.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/link-usq8ypw9.js",
        "/_next/static/chunks/index-CTjh5y2D.js",
        "/_next/static/chunks/app-elements-H_Dr48wG.js",
        "/_next/static/chunks/hash-Cp347hhd.js",
        "/_next/static/chunks/record-uXSNv6cl.js",
        "/_next/static/chunks/app-rsc-cache-busting-CR318oad.js",
        "/_next/static/chunks/app-rsc-render-mode-CvTCGruk.js",
        "/_next/static/chunks/headers-C_MtfdF4.js",
        "/_next/static/chunks/protocol-headers-B9-bVeat.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-D5LMQqDL.js",
        "/_next/static/chunks/app-route-prefetch-policy-DlffY3q2.js",
        "/_next/static/chunks/query-CJ3eS_iZ.js",
        "/_next/static/chunks/circle-x-Dv9vJueo.js"
      ],
      "css": []
    },
    "97eb53b8ab79": {
      "js": [
        "/_next/static/chunks/course-page-client-ByVYMPPg.js",
        "/_next/static/chunks/site-footer-D9UXbJb6.js",
        "/_next/static/chunks/site-header-NG0pkwPJ.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/Icon-nzziIqKm.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/link-usq8ypw9.js",
        "/_next/static/chunks/index-CTjh5y2D.js",
        "/_next/static/chunks/app-elements-H_Dr48wG.js",
        "/_next/static/chunks/hash-Cp347hhd.js",
        "/_next/static/chunks/record-uXSNv6cl.js",
        "/_next/static/chunks/app-rsc-cache-busting-CR318oad.js",
        "/_next/static/chunks/app-rsc-render-mode-CvTCGruk.js",
        "/_next/static/chunks/headers-C_MtfdF4.js",
        "/_next/static/chunks/protocol-headers-B9-bVeat.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-D5LMQqDL.js",
        "/_next/static/chunks/app-route-prefetch-policy-DlffY3q2.js",
        "/_next/static/chunks/query-CJ3eS_iZ.js",
        "/_next/static/chunks/image-Dw955Uma.js"
      ],
      "css": []
    },
    "b7d9b84eee67": {
      "js": [
        "/_next/static/chunks/home-client-MtxLmFop.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/site-footer-D9UXbJb6.js",
        "/_next/static/chunks/site-header-NG0pkwPJ.js",
        "/_next/static/chunks/Icon-nzziIqKm.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/link-usq8ypw9.js",
        "/_next/static/chunks/index-CTjh5y2D.js",
        "/_next/static/chunks/app-elements-H_Dr48wG.js",
        "/_next/static/chunks/hash-Cp347hhd.js",
        "/_next/static/chunks/record-uXSNv6cl.js",
        "/_next/static/chunks/app-rsc-cache-busting-CR318oad.js",
        "/_next/static/chunks/app-rsc-render-mode-CvTCGruk.js",
        "/_next/static/chunks/headers-C_MtfdF4.js",
        "/_next/static/chunks/protocol-headers-B9-bVeat.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-D5LMQqDL.js",
        "/_next/static/chunks/app-route-prefetch-policy-DlffY3q2.js",
        "/_next/static/chunks/query-CJ3eS_iZ.js",
        "/_next/static/chunks/dialog-CpdV5-tC.js",
        "/_next/static/chunks/image-Dw955Uma.js"
      ],
      "css": []
    },
    "0993e234661d": {
      "js": [
        "/_next/static/chunks/profile-client-DezT_Sks.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/site-footer-D9UXbJb6.js",
        "/_next/static/chunks/site-header-NG0pkwPJ.js",
        "/_next/static/chunks/Icon-nzziIqKm.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/link-usq8ypw9.js",
        "/_next/static/chunks/index-CTjh5y2D.js",
        "/_next/static/chunks/app-elements-H_Dr48wG.js",
        "/_next/static/chunks/hash-Cp347hhd.js",
        "/_next/static/chunks/record-uXSNv6cl.js",
        "/_next/static/chunks/app-rsc-cache-busting-CR318oad.js",
        "/_next/static/chunks/app-rsc-render-mode-CvTCGruk.js",
        "/_next/static/chunks/headers-C_MtfdF4.js",
        "/_next/static/chunks/protocol-headers-B9-bVeat.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-D5LMQqDL.js",
        "/_next/static/chunks/app-route-prefetch-policy-DlffY3q2.js",
        "/_next/static/chunks/query-CJ3eS_iZ.js",
        "/_next/static/chunks/dialog-CpdV5-tC.js",
        "/_next/static/chunks/image-Dw955Uma.js",
        "/_next/static/chunks/circle-x-Dv9vJueo.js"
      ],
      "css": []
    },
    "30fd01720cb9": {
      "js": [
        "/_next/static/chunks/site-header-NG0pkwPJ.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/Icon-nzziIqKm.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/link-usq8ypw9.js",
        "/_next/static/chunks/index-CTjh5y2D.js",
        "/_next/static/chunks/app-elements-H_Dr48wG.js",
        "/_next/static/chunks/hash-Cp347hhd.js",
        "/_next/static/chunks/record-uXSNv6cl.js",
        "/_next/static/chunks/app-rsc-cache-busting-CR318oad.js",
        "/_next/static/chunks/app-rsc-render-mode-CvTCGruk.js",
        "/_next/static/chunks/headers-C_MtfdF4.js",
        "/_next/static/chunks/protocol-headers-B9-bVeat.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-D5LMQqDL.js",
        "/_next/static/chunks/app-route-prefetch-policy-DlffY3q2.js",
        "/_next/static/chunks/query-CJ3eS_iZ.js"
      ],
      "css": []
    },
    "fda5a0865555": {
      "js": [
        "/_next/static/chunks/Icon-nzziIqKm.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/index-CTjh5y2D.js",
        "/_next/static/chunks/app-elements-H_Dr48wG.js",
        "/_next/static/chunks/hash-Cp347hhd.js",
        "/_next/static/chunks/record-uXSNv6cl.js",
        "/_next/static/chunks/app-rsc-cache-busting-CR318oad.js",
        "/_next/static/chunks/app-rsc-render-mode-CvTCGruk.js",
        "/_next/static/chunks/headers-C_MtfdF4.js",
        "/_next/static/chunks/protocol-headers-B9-bVeat.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-D5LMQqDL.js"
      ],
      "css": []
    },
    "3580e83793ff": {
      "js": [
        "/_next/static/chunks/index-CTjh5y2D.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/app-elements-H_Dr48wG.js",
        "/_next/static/chunks/hash-Cp347hhd.js",
        "/_next/static/chunks/record-uXSNv6cl.js",
        "/_next/static/chunks/app-rsc-cache-busting-CR318oad.js",
        "/_next/static/chunks/app-rsc-render-mode-CvTCGruk.js",
        "/_next/static/chunks/headers-C_MtfdF4.js",
        "/_next/static/chunks/protocol-headers-B9-bVeat.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-D5LMQqDL.js"
      ],
      "css": []
    },
    "896f66136070": {
      "js": [
        "/_next/static/chunks/index-CTjh5y2D.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/app-elements-H_Dr48wG.js",
        "/_next/static/chunks/hash-Cp347hhd.js",
        "/_next/static/chunks/record-uXSNv6cl.js",
        "/_next/static/chunks/app-rsc-cache-busting-CR318oad.js",
        "/_next/static/chunks/app-rsc-render-mode-CvTCGruk.js",
        "/_next/static/chunks/headers-C_MtfdF4.js",
        "/_next/static/chunks/protocol-headers-B9-bVeat.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-D5LMQqDL.js"
      ],
      "css": []
    },
    "61a44cc8cec6": {
      "js": [
        "/_next/static/chunks/index-CTjh5y2D.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/app-elements-H_Dr48wG.js",
        "/_next/static/chunks/hash-Cp347hhd.js",
        "/_next/static/chunks/record-uXSNv6cl.js",
        "/_next/static/chunks/app-rsc-cache-busting-CR318oad.js",
        "/_next/static/chunks/app-rsc-render-mode-CvTCGruk.js",
        "/_next/static/chunks/headers-C_MtfdF4.js",
        "/_next/static/chunks/protocol-headers-B9-bVeat.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-D5LMQqDL.js"
      ],
      "css": []
    },
    "7f3c04ed6969": {
      "js": [
        "/_next/static/chunks/index-CTjh5y2D.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/app-elements-H_Dr48wG.js",
        "/_next/static/chunks/hash-Cp347hhd.js",
        "/_next/static/chunks/record-uXSNv6cl.js",
        "/_next/static/chunks/app-rsc-cache-busting-CR318oad.js",
        "/_next/static/chunks/app-rsc-render-mode-CvTCGruk.js",
        "/_next/static/chunks/headers-C_MtfdF4.js",
        "/_next/static/chunks/protocol-headers-B9-bVeat.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-D5LMQqDL.js"
      ],
      "css": []
    },
    "f440fc242bed": {
      "js": [
        "/_next/static/chunks/layout-segment-context-B2QTo8NJ.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/index-CTjh5y2D.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/app-elements-H_Dr48wG.js",
        "/_next/static/chunks/hash-Cp347hhd.js",
        "/_next/static/chunks/record-uXSNv6cl.js",
        "/_next/static/chunks/app-rsc-cache-busting-CR318oad.js",
        "/_next/static/chunks/app-rsc-render-mode-CvTCGruk.js",
        "/_next/static/chunks/headers-C_MtfdF4.js",
        "/_next/static/chunks/protocol-headers-B9-bVeat.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-D5LMQqDL.js"
      ],
      "css": []
    },
    "c2747888630f": {
      "js": [
        "/_next/static/chunks/link-usq8ypw9.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/index-CTjh5y2D.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/app-elements-H_Dr48wG.js",
        "/_next/static/chunks/hash-Cp347hhd.js",
        "/_next/static/chunks/record-uXSNv6cl.js",
        "/_next/static/chunks/app-rsc-cache-busting-CR318oad.js",
        "/_next/static/chunks/app-rsc-render-mode-CvTCGruk.js",
        "/_next/static/chunks/headers-C_MtfdF4.js",
        "/_next/static/chunks/protocol-headers-B9-bVeat.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-D5LMQqDL.js",
        "/_next/static/chunks/app-route-prefetch-policy-DlffY3q2.js",
        "/_next/static/chunks/query-CJ3eS_iZ.js"
      ],
      "css": []
    },
    "500c189759fa": {
      "js": [
        "/_next/static/chunks/index-CTjh5y2D.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/app-elements-H_Dr48wG.js",
        "/_next/static/chunks/hash-Cp347hhd.js",
        "/_next/static/chunks/record-uXSNv6cl.js",
        "/_next/static/chunks/app-rsc-cache-busting-CR318oad.js",
        "/_next/static/chunks/app-rsc-render-mode-CvTCGruk.js",
        "/_next/static/chunks/headers-C_MtfdF4.js",
        "/_next/static/chunks/protocol-headers-B9-bVeat.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-D5LMQqDL.js"
      ],
      "css": []
    },
    "da5e1933e52f": {
      "js": [
        "/_next/static/chunks/streamed-icons-IgD2kPLc.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/index-CTjh5y2D.js",
        "/_next/static/chunks/app-elements-H_Dr48wG.js",
        "/_next/static/chunks/hash-Cp347hhd.js",
        "/_next/static/chunks/record-uXSNv6cl.js",
        "/_next/static/chunks/app-rsc-cache-busting-CR318oad.js",
        "/_next/static/chunks/app-rsc-render-mode-CvTCGruk.js",
        "/_next/static/chunks/headers-C_MtfdF4.js",
        "/_next/static/chunks/protocol-headers-B9-bVeat.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-D5LMQqDL.js"
      ],
      "css": []
    }
  },
  "serverResources": {
    "app/layout.tsx": {
      "js": [],
      "css": [
        "/_next/static/css/index.BIgTDvnL.css"
      ]
    }
  }
}